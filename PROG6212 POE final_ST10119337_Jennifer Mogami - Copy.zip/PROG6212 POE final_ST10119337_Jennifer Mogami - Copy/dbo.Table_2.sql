﻿CREATE TABLE [school].[SemesterInformation]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NumberOfWeeks] INT NOT NULL, 
    [StartDate] DATETIME NULL
)
